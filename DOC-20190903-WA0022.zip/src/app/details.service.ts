import { Injectable } from '@angular/core';
import { Details } from './details';
import {HttpClientModule,HttpClient} from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';


@Injectable({
  providedIn: 'root'
})
export class DetailsService {

  url:string='/assets/data/details.json';

  constructor(private http:HttpClient) {}
    getAllEmployees():Observable<Details[]>
    {
      return this.http.get<Details[]>(this.url);
    }
}
