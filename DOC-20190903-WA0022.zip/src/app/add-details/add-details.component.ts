import { Component, OnInit } from '@angular/core';
import { Details } from '../details';
import { DetailsService } from '../details.service';

@Component({
  selector: 'app-add-details',
  templateUrl: './add-details.component.html',
  styleUrls: ['./add-details.component.css']
})
export class AddDetailsComponent implements OnInit {

  empList:Details[];
  constructor(private service:DetailsService) { }

  ngOnInit() {
    this.getAllEmployees();
  }

  getAllEmployees()
  {
    this.service.getAllEmployees().subscribe(data=>this.empList=data);
  }
  addEmployee(myform1){
    this.empList.push(myform1.value);
  }
  
  

}
