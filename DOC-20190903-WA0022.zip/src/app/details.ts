export interface Details{
    eid:number;
    ename:string;
    email:number;
    phone:string;
    
    
    }