import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule,HttpClient} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import {RouterModule,Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { AllDetailsComponent } from './all-details/all-details.component';
import { AddDetailsComponent } from './add-details/add-details.component';
import { AppRoutingModule } from './app-routing.module';
import { DetailsService } from './details.service';

const routes:Routes=[
  {path:'all',component:AllDetailsComponent},
  {path:'add',component:AddDetailsComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    AllDetailsComponent,
    AddDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)

  ],
  providers: [DetailsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
