import { Component, OnInit } from '@angular/core';
import { Details } from '../details';
import { DetailsService } from '../details.service';

@Component({
  selector: 'app-all-details',
  templateUrl: './all-details.component.html',
  styleUrls: ['./all-details.component.css']
})
export class AllDetailsComponent implements OnInit {

  empList:Details[];
  constructor(private service:DetailsService) { }

  ngOnInit() {
    this.getAllEmployees();
  }

  getAllEmployees()
  {
    this.service.getAllEmployees().subscribe(data=>this.empList=data);
  }
  deleteemployeeInfo(i)
  {
    this.empList.splice(i,1);
  }
 
    

  updateEmployee(updateform)
   {
  let count=0;
  for(let i=0;i<this.empList.length; i++)
   {
  if(this.empList[i].eid==updateform.value.eid)
   {
  this.empList[i]=updateform.value;
  count=1;
   }
   }
  if(count==0)
   {
  alert('updation failed');
   }
   }
  
  
  

}
