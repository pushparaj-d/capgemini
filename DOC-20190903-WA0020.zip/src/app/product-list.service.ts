import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { Product } from './product';

@Injectable({
 providedIn: 'root'
})
export class ProductListService {

 constructor(private http: HttpClient) { }

 url = '/assets/data/products.json';

 getAllProducts(): Observable< Product []> {
 return this.http.get< Product[]>(this.url);
 }
}
